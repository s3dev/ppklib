=============================================
pypi.py - Wrappers for querying the PyPI APIs
=============================================

.. automodule:: ppklib.pypi

