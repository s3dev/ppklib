================================================================
Object: pypiapiobject.py - Object for querying the PyPI JSON API
================================================================

.. automodule:: ppklib.objects.pypiapiobject

