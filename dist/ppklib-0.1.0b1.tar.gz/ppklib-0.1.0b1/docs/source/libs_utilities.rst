==============================================
Lib: utilities.py - Private internal utilities
==============================================

.. automodule:: ppklib.libs.utilities

