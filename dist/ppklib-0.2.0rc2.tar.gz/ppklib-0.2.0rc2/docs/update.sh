#!/usr/bin/env bash

. ./.constants.config

sphinx-build $dirsource $dirbuild -b html

