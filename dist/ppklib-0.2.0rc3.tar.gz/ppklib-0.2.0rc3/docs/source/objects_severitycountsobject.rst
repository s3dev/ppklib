======================================================================
Object: severitycountsobject.py - Object container for severity counts
======================================================================

.. automodule:: ppklib.objects.severitycountsobject

