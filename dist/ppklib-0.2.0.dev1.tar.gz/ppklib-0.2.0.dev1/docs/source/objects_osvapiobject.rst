=========================================================
Object: osvapiobject.py - Object for querying the OSV API
=========================================================

.. automodule:: ppklib.objects.osvapiobject

