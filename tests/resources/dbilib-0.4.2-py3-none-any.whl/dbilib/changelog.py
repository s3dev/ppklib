# Enable sphinx to access the Git log.
"""
.. git_changelog::
    :revisions: 99
    :detailed-message-pre: True
"""
